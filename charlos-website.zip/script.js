// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Nav shadow on scroll
  const nav = document.querySelector('.nav');
  if (nav) {
    const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // Scroll-triggered reveal animations
  if (!prefersReducedMotion && 'IntersectionObserver' in window) {
    const revealEls = document.querySelectorAll('.reveal');
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(el => revealObserver.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('in-view'));
  }

  // Count-up animation for hero stats
  const statNums = document.querySelectorAll('.stat-num[data-count]');
  if (statNums.length && !prefersReducedMotion && 'IntersectionObserver' in window) {
    const statObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = el.getAttribute('data-count');
        const numeric = parseInt(target.replace(/\D/g, ''), 10);
        const prefix = target.match(/^\D*/)[0];
        const suffix = target.match(/\D*$/)[0];
        const duration = 1100;
        const start = performance.now();
        function tick(now) {
          const progress = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          el.textContent = prefix + Math.round(numeric * eased) + suffix;
          if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        statObserver.unobserve(el);
      });
    }, { threshold: 0.5 });
    statNums.forEach(el => statObserver.observe(el));
  }

  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      links.classList.toggle('open');
    });
  }

  // Category accordion
  document.querySelectorAll('.cat-card').forEach(card => {
    const head = card.querySelector('.cat-head');
    if (!head) return;
    head.addEventListener('click', () => {
      card.classList.toggle('open');
    });
  });

  // Hero embed mockup rotation
  const embeds = [
    {
      icon: '📋',
      label: 'Help Menu',
      title: '📋 Charlos Help & Commands',
      desc: 'Multipurpose Discord bot with economy, moderation, fun games, and utility features. Browse commands by category.',
      footer: '🤖 Charlos — Help Menu'
    },
    {
      icon: '🔨',
      label: 'Moderation',
      title: '🔨 Moderation Commands',
      desc: 'Keep your server safe and organized.',
      code: 'ban · mute · warn · purge · lock · kick',
      footer: '🤖 Charlos — Moderation'
    },
    {
      icon: '💰',
      label: 'Economy',
      title: '💰 Economy Commands',
      desc: 'Earn coins, play mini-games, climb the leaderboards.',
      code: 'daily · rob · mine · fish · shop · work',
      footer: '🤖 Charlos — Economy'
    },
    {
      icon: '🎉',
      label: 'Fun',
      title: '🎉 Fun Commands',
      desc: 'Cure your boredom with games and tricks.',
      code: '8ball · rps · marry · trivia · roast',
      footer: '🤖 Charlos — Fun'
    },
    {
      icon: '🖼️',
      label: 'Image',
      title: '🖼️ Image Commands',
      desc: 'Generate memes, filters, and roleplay actions.',
      code: 'hug · slap · pat · jail · wanted · drip',
      footer: '🤖 Charlos — Image'
    }
  ];

  const embedCard = document.querySelector('.embed-card');
  const dotsWrap = document.querySelector('.mockup-dots');
  const selectIcon = document.querySelector('.mockup-select .select-icon');
  const selectText = document.querySelector('.mockup-select .select-text');

  if (embedCard && dotsWrap) {
    let idx = 0;
    let timer;

    function render(i) {
      const e = embeds[i];
      embedCard.style.opacity = 0;
      setTimeout(() => {
        embedCard.innerHTML = `
          <div class="embed-title">${e.title}</div>
          <div class="embed-desc">${e.desc}</div>
          ${e.code ? `<span class="embed-code">${e.code}</span>` : ''}
          <div class="embed-footer">${e.footer}</div>
        `;
        if (selectIcon) selectIcon.textContent = e.icon;
        if (selectText) selectText.textContent = e.label;
        embedCard.style.opacity = 1;
      }, 180);

      [...dotsWrap.children].forEach((d, di) => d.classList.toggle('active', di === i));
    }

    embeds.forEach((_, i) => {
      const b = document.createElement('button');
      b.setAttribute('aria-label', 'Show embed ' + (i + 1));
      b.addEventListener('click', () => {
        idx = i;
        render(idx);
        resetTimer();
      });
      dotsWrap.appendChild(b);
    });

    function resetTimer() {
      clearInterval(timer);
      timer = setInterval(() => {
        idx = (idx + 1) % embeds.length;
        render(idx);
      }, 3200);
    }

    render(0);
    resetTimer();
  }
});
